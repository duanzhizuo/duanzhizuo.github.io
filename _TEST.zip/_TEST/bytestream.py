# coding:utf-8
# @Version : 1.0
# @File : bytestream.py
# @Date : 2024/7/7-23:47
# @Author : 李霸天


# 使用bytearray()函数创建字节数组对象

"""
    request:{
        "fixed":[
            {}

        ]

    }
"""
import json

from _TEST.bbrf_parse import BbrfParser


def len2bytes(len: str, data: bytearray, offset: int):
    relen = int(len)
    print(relen)


"""
从Word中解析成的表格子分为3类
按照命令字的作为key，表格列表作为value
筛选只有1个的表格，将其作为report的类型
筛选有三个的表哥，并且3个为Req resp_s resp_f的作为正常的request repsone_success repsone_fail



正常的有三个


如果只有1个的，视为report，并且1个内容不带ExecResult

如果解析过程中，任何命字有问题就剔除该命令字，直到修正此命令字的word为止
"""


# 确定类型
def find_msg_type(direction: str, data: bytearray):
    # 判断方向
    if direction == '下行':
        return "request"

    if direction == '上行':
        if len(data) == 2:
            return "resp_fail"
        else:
            return "mix"  # 实际结合命来的json来看，如果只有1个则为report，否则则为response_success


def re_find_msg_type(json_meta: dict, cmd_lower):
    if cmd_lower in json_meta:
        msg_types = json_meta.get(cmd_lower)
        if len(msg_types) == 1:
            return "report"
        return "request_success"

    return "mix"




if __name__ == '__main__':
    cmd_lower = "0x4b"
    data = bytearray([0x1, 101, 108, 108, 111])
    with open("./json_meta.json", "r") as f:
        json_meta = json.load(f)

    msg_type = find_msg_type("上行", data)
    if msg_type == "mix":
        # 再次确定类型
        msg_type = re_find_msg_type(json_meta, cmd_lower)
        if msg_type == "mix":
            exit(1)

    parser = BbrfParser(data, msg_type, cmd_lower, json_meta)
    res = parser.parse()

    len2bytes("1", data, 1)
    # parser.cur_offset += 1
    # print(obj.cur_offset)  # 0001 00000101
    # a = int.from_bytes(obj.data[0:2], byteorder="big", signed=False)
    # print(a)

"""

带N的 且N一般为上一个值，
4*N
N*4
    1.如果type是struct 则是正常的 大概率 
    2.如果type不是struct 则按照数字（根据type来） * 数量（循环） 来呈现



并不是struct
1*N


如果直接是 1*2  1*15  16这样的
    按照计算好的


INT
UNINT
CHAR
ENUM
BITMAP
STRUCT 

"""
