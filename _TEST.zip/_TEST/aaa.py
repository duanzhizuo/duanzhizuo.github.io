# coding:utf-8
# @Version : 1.0
# @File : aaa.py
# @Date : 2024/7/8-03:12
# @Author : 李霸天
import re

"""

INT
UNINT
CHAR
ENUM
BITMAP
STRUCT 
"""


if __name__ == '__main__':

    len_str = "4*N"
    pattern_number = r"^\d+$"  # 纯数字
    pattern_n = r"^(\d+\*[N]|[N]\*\d+)$"  # number * N  N * number的

    pattern_n2 = r"^(\d+\*\d+)$"  # 1*2 1*4 3*4等固定长度等

    compile_ = re.compile(pattern_number)
    res = compile_.match(len_str)
    if res:
        print("字符串只包含数字字符")
    else:
        print("字符串包含非数字字符")

    match2 = re.match(pattern_n, len_str.replace(" ", ""))

    if match2:
        n_value = match2.group(0)
        num = re.search(r"\d+", n_value).group()
        print(num)

    match3 = re.match(pattern_n2,len_str)
    if match3:
        pass
