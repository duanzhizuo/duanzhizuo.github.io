# coding:utf-8
# @Version : 1.0
# @File : bbrf_parse.py
# @Date : 2024/7/8-00:22
# @Author : 李霸天

class BbrfParser:

    def __init__(self, data: bytearray, msg_type: str, cmd_lower: str, json_meta: dict):
        self.cur_offset = 0
        self.data = data
        self.msg_type = msg_type
        self.cmd_lower = cmd_lower
        self.json_meta = json_meta

    def parse(self):
        json_parse = {}
        msg_types: dict = self.json_meta[self.cmd_lower]
        if self.msg_type in msg_types:

            fixed_meta = msg_types[self.msg_type]["fixed"]
            if fixed_meta:
                self.parse_fixed_meta(json_parse, fixed_meta)
                pass

            tlvs_meta = msg_types[self.msg_type]["tlvs"]
            if self.msg_type in tlvs_meta:
                pass
            pass

        return json_parse

    def parse_fixed_meta(self, json_parse, fixed_meta):

        json_parse.update("fixed_data", {})
        struct_number = 0
        parse_type_value = {
            "int": self.build_int_len,
            "unint": self.build_unint_len,
            "char": self.build_char_len,
            "enum": self.build_enum_len,
            "bitmap": self.build_bitmap_len,
            "struct": self.build_struct_len
        }

        for fixed_element in fixed_meta:
            t_name: str = fixed_element['name']
            t_len: str = fixed_element['len']  # len要和type结合
            t_type: str = fixed_element['type']

            if t_type == 'struct':
                struct_meta_dict = fixed_element["struct_meta"]
                # 数组
                val = self.parse_struct_type_value(t_name, t_len, struct_number, struct_meta_dict)
                json_parse["fixed_data"][t_name] = val
            else:
                val = parse_type_value[self.judge_type(t_type)](t_len)
                json_parse["fixed_data"][t_name] = val
                struct_number = val
            self.cur_offset += t_len

        pass

    def parse_struct_type_value(self, t_name, t_len, struct_number, struct_meta_dict):
        """
        需要结合t_len 和 struct_number来看
        1、一般struct进行解析时，以struct_number为数量
        """
        parse_type_value = {
            "int": self.build_int_len,
            "unint": self.build_unint_len,
            "char": self.build_char_len,
            "enum": self.build_enum_len,
            "bitmap": self.build_bitmap_len,
            "struct": self.build_struct_len
        }
        struct_list = []
        for i in range(struct_number):
            struct_item = {}
            for item in struct_meta_dict:
                t_name: str = item['name']
                t_len: str = item['len']
                t_type: str = item['type']
                struct_item[t_name] = parse_type_value[self.judge_type(t_type)](t_len)
            struct_list.append(struct_item)

        return struct_list

    def judge_type(self, type_str: str):
        if type_str.lower().find("int") != -1:
            print("int")
        elif type_str.lower().find("unint") != -1:
            print("unint")
        elif type_str.lower().find("char") != -1:
            print("char")
        elif type_str.lower().find("enum") != -1:
            print("enum")
        elif type_str.lower().find("bitmap") != -1:
            print("bitmap")
        elif type_str.lower().find("struct") != -1:
            print("struct")
        else:
            print("null")

    def build_int_len(self, t_len):

        _len = int(t_len)
        int.from_bytes(self.data[self.cur_offset:self.cur_offset + _len], byteorder='big', signed=True)
        self.cur_offset += _len
        pass

    def build_unint_len(self, t_len):
        pass

    def build_char_len(self, t_len):
        pass

    def build_enum_len(self, t_len):
        pass

    def build_bitmap_len(self, t_len, struct_meta_dict):
        pass

    def build_struct_len(self, t_name, t_len, struct_number, struct_meta_dict):
        pass


def f1(len:str):
    pass


if __name__ == '__main__':

    pass